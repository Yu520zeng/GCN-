
function Y = model(parameters, X, A)

%%  获得网络的输入
Z1 = X;

%%  图卷积层 1
Z2 = pagemtimes(pagemtimes(A, Z1), parameters.mult1.Weights);
Z2 = relu(Z2) + Z1;

%%  图卷积层 2
Z3 = pagemtimes(pagemtimes(A, Z2), parameters.mult2.Weights);
Z3 = relu(Z3) + Z2;

%%  图卷积层 3
Z4 = pagemtimes(pagemtimes(A, Z3), parameters.mult3.Weights);
Z4 = squeeze(Z4);

%%  分类层
Z5 = parameters.mult4.Weights' * Z4;
Y = softmax(Z5, DataFormat="BC")';

end

