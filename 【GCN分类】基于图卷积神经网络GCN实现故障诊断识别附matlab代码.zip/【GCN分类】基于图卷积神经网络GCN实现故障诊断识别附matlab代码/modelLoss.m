
function [loss, gradients] = modelLoss(parameters, X, A, T)

%%  获得网络输出
Y = model(parameters, X, A);

%%  获得损失函数
loss = crossentropy(Y, T, DataFormat="BC");

%%  获得梯度
gradients = dlgradient(loss, parameters);

end